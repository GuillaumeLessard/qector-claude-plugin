# QECTOR Decoder v3 custom connector

A hosted [MCP](https://modelcontextprotocol.io) **Streamable HTTP** endpoint
that exposes the same eight QECTOR Decoder v3 tools as the local stdio library
server (`mcp/mcp_server_library.py`), with the same fail-closed guarantees:

- every returned correction passes `H c = s (mod 2)` (Theorem 1);
- logical outcomes are scored with the logical-observable matrix (Theorem 2);
- every LER sweep includes a 95% Wilson interval and a hashed raw JSON artifact.

This is the service you register in **claude.ai as a custom connector**
(Settings → Connectors → Add custom → MCP server URL).

## Tools

`list_code_families`, `list_decoders`, `get_license_info`, `decode_syndrome`,
`decode_single`, `threshold_sweep`, `build_code_from_matrix`, `compat_report`.

## Endpoints

| Method | Path      | Purpose                                                |
|--------|-----------|--------------------------------------------------------|
| GET    | `/health` | liveness probe; versions, license tier, resource limits |
| GET    | `/`       | endpoint index                                          |
| POST   | `/mcp`    | MCP Streamable HTTP (JSON-RPC 2.0)                      |

## Run locally

```bash
pip install -r requirements-connector.txt
python qector_connector_server.py
```

Smoke test the process without binding a socket:

```bash
python qector_connector_server.py --check
```

Then verify the live endpoint:

```bash
curl http://127.0.0.1:8000/health
```

## MCP handshake test

The endpoint speaks standard MCP. A minimal session (initialize, then
`tools/list`) works over plain HTTP:

```bash
curl -s -X POST http://127.0.0.1:8000/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"curl","version":"1.0"}}}'

curl -s -X POST http://127.0.0.1:8000/mcp \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":2,"method":"tools/list"}'
```

Any MCP client (Claude Desktop, MCP Inspector, claude.ai custom connector)
can point at `http://<host>:8000/mcp`.

## Authentication

By default the endpoint is open. To require a bearer token:

```bash
QECTOR_CONNECTOR_TOKEN=<secret> python qector_connector_server.py
```

Every request must then send `Authorization: Bearer <secret>`; without it the
server answers `401`. claude.ai's custom-connector UI does not send custom
headers, so either keep the endpoint open (recommended for a public demo) or
terminate TLS + auth at a reverse proxy in front of this service.

## Deployment

### Docker

Build from the `mcp/` directory (the context needs both the library and the
connector):

```bash
cd mcp
docker build -f connector/Dockerfile -t qector-connector .
docker run --rm -p 8000:8000 -e QECTOR_CONNECTOR_TOKEN= qector-connector
```

The image runs `python qector_connector_server.py`, listens on `0.0.0.0:8000`,
and has a `/health` Docker healthcheck.

### Render / Railway / Fly.io

These platforms accept the same image (or the plain Python start command):

- Start command: `python qector_connector_server.py`
- Expose port `8000`
- Health check path: `/health`

After deployment the connector URL is `https://<your-service>/mcp`.

## Environment

| Variable                  | Default        | Meaning                                   |
|---------------------------|----------------|-------------------------------------------|
| `QECTOR_CONNECTOR_HOST`   | `0.0.0.0`      | bind host                                 |
| `QECTOR_CONNECTOR_PORT`   | `8000`         | bind port                                 |
| `QECTOR_CONNECTOR_TOKEN`  | *(unset)*      | static bearer token; empty = open         |
| `QECTOR_ARTIFACT_DIR`     | `./artifacts`  | threshold_sweep artifact output directory |
| `QECTOR_MCP_MAX_*`        | library limits | resource caps, see `mcp_server_library.py`|

## Register in claude.ai

1. Deploy the service and confirm `GET /health` returns `{"status":"ok",...}`.
2. In claude.ai open **Settings → Connectors**.
3. Choose the custom / MCP option and enter `https://<your-service>/mcp`.
4. The connector should connect and expose the eight QECTOR tools; verify with
   `list_code_families` or `decode_syndrome`.

## Resource limits

The same process-level safety caps as the stdio server apply
(`MAX_DISTANCE=63`, `MAX_CHECKS=10000`, `MAX_QUBITS=100000`,
`MAX_MATRIX_CELLS=1000000`, `MAX_TRIALS=100000`, `MAX_SWEEP_POINTS=256`).
The QECTOR license tier remains the authority for distance limits.