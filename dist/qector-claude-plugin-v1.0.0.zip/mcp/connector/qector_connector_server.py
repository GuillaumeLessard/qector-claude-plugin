"""
QECTOR Decoder v3 custom connector.

Hosted Streamable HTTP MCP endpoint for claude.ai custom connectors and any
other remote MCP client. It reuses the exact library contract from
``mcp/mcp_server_library.py``: the same eight tools, the same fail-closed
``H c = s (mod 2)`` guarantee, the same Wilson-interval LER sweeps, and the
same resource limits. No new capability is exposed here; the connector only
adds a network surface.

Endpoints
---------
    GET  /health   liveness probe + server/QECTOR versions + license tier
    GET  /         human-readable endpoint index
    POST /mcp      MCP Streamable HTTP (JSON-RPC 2.0) tool endpoint

Quick start
-----------
    pip install -r requirements-connector.txt
    python qector_connector_server.py

Then point any MCP client at ``http://127.0.0.1:8000/mcp``, or register that
URL in claude.ai as a custom connector.

Environment
-----------
    QECTOR_CONNECTOR_HOST   bind host            (default 0.0.0.0)
    QECTOR_CONNECTOR_PORT   bind port            (default 8000)
    QECTOR_CONNECTOR_TOKEN  optional bearer token; when set every request
                            must send ``Authorization: Bearer <token>``
    QECTOR_ARTIFACT_DIR     where threshold_sweep artifacts are written
                            (default ./artifacts)
    QECTOR_MCP_MAX_*        resource limits, see mcp_server_library.py
"""

from __future__ import annotations

import argparse
import os
import sys
import time
from pathlib import Path

_QECTOR_LIBRARY_PATH = str(Path(__file__).resolve().parent.parent)
if _QECTOR_LIBRARY_PATH not in sys.path:
    sys.path.insert(0, _QECTOR_LIBRARY_PATH)

import mcp_server_library as library  # noqa: E402

SERVER_NAME = "qector-decoder-v3-connector"
SERVER_VERSION = "1.0.0"
STARTED_AT = time.time()


def _bearer_token() -> str | None:
    configured = os.environ.get("QECTOR_CONNECTOR_TOKEN")
    if configured is None:
        return None
    configured = configured.strip()
    return configured or None


def _licence_summary() -> dict:
    try:
        info = library.get_license_info().get("license", {})
        if isinstance(info, dict):
            return {
                "tier": info.get("tier"),
                "mode": info.get("mode"),
                "terms": info.get("terms"),
            }
        return {"tier": None, "mode": None, "terms": None}
    except Exception:
        return {"tier": "unavailable", "mode": None, "terms": None}


def _health_payload() -> dict:
    return {
        "status": "ok",
        "service": SERVER_NAME,
        "version": SERVER_VERSION,
        "uptime_seconds": round(time.time() - STARTED_AT, 3),
        "qector_decoder_v3": library.QECTOR_VERSION,
        "reference_manual": library.REF_DOI,
        "license": _licence_summary(),
        "transport": {
            "type": "streamable-http",
            "endpoint": "/mcp",
            "protocol": "JSON-RPC 2.0 over HTTP + SSE",
        },
        "tools": [tool.name for tool in library.TOOLS],
        "resource_limits": {
            "max_distance": library.MAX_DISTANCE,
            "max_checks": library.MAX_CHECKS,
            "max_qubits": library.MAX_QUBITS,
            "max_matrix_cells": library.MAX_MATRIX_CELLS,
            "max_trials": library.MAX_TRIALS,
            "max_sweep_points": library.MAX_SWEEP_POINTS,
        },
    }


def _index_payload() -> dict:
    return {
        "service": SERVER_NAME,
        "version": SERVER_VERSION,
        "description": (
            "QECTOR Decoder v3 remote MCP connector. "
            "Connect this URL as a claude.ai custom connector."
        ),
        "endpoints": {
            "GET /health": "liveness probe with versions, license tier and resource limits",
            "GET /": "this index",
            "POST /mcp": "MCP Streamable HTTP tool endpoint (initialize, tools/list, tools/call)",
        },
        "tools": [tool.name for tool in library.TOOLS],
        "documentation": "see mcp/connector/README.md in the qector-claude-skills repository",
    }


def _make_handler(tool_name: str):
    def handler(**arguments: object) -> dict:
        return library.dispatch_tool(tool_name, arguments)

    handler.__name__ = tool_name
    return handler


def build_server() -> dict:
    """Build the FastMCP server and register the eight library tools."""
    from mcp.server.fastmcp import FastMCP

    server = FastMCP(
        name=SERVER_NAME,
        instructions=(
            "Remote QECTOR decoder tools. Every returned correction is "
            "fail-closed against H c = s (mod 2) (Theorem 1); logical "
            "outcomes are scored with the logical-observable matrix "
            "(Theorem 2); every LER sweep carries a 95% Wilson interval and "
            "a hashed raw JSON artifact."
        ),
        host="0.0.0.0",
        port=8000,
        log_level="INFO",
        stateless_http=True,
    )

    for spec in library.TOOLS:
        server.add_tool(
            _make_handler(spec.name),
            name=spec.name,
            description=spec.description,
        )
        server._tool_manager.get_tool(spec.name).parameters = spec.inputSchema

    @server.custom_route("/health", methods=["GET"])
    async def health(request) -> dict:
        return _health_payload()

    @server.custom_route("/", methods=["GET"])
    async def index(request) -> dict:
        return _index_payload()

    return {"server": server, "tools": library.TOOLS}


class _BearerTokenMiddleware:
    """Static bearer-token guard applied in front of the MCP app."""

    def __init__(self, app, token: str):
        self._app = app
        self._expected = f"Bearer {token}"

    async def __call__(self, scope, receive, send):
        if scope["type"] != "http":
            await self._app(scope, receive, send)
            return
        headers = {k.decode("latin-1").lower(): v.decode("latin-1") for k, v in scope.get("headers", [])}
        if headers.get("authorization") == self._expected:
            await self._app(scope, receive, send)
            return
        from starlette.responses import JSONResponse

        response = JSONResponse(
            {"detail": "unauthorized: QECTOR_CONNECTOR_TOKEN required"},
            status_code=401,
        )
        await response(scope, receive, send)


def build_app(token: str | None = None):
    built = build_server()
    app = built["server"].streamable_http_app()
    if token:
        app = _BearerTokenMiddleware(app, token)
    return app


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="QECTOR Decoder v3 custom connector (Streamable HTTP MCP)"
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="print the health payload and exit without binding a socket",
    )
    args = parser.parse_args(argv)

    if args.check:
        import json

        print(json.dumps(_health_payload(), sort_keys=True, indent=2))
        return 0

    token = _bearer_token()
    if token:
        print(f"[{SERVER_NAME}] bearer authentication enabled")
    else:
        print(f"[{SERVER_NAME}] bearer authentication disabled (set QECTOR_CONNECTOR_TOKEN to enable)")

    import uvicorn

    host = os.environ.get("QECTOR_CONNECTOR_HOST", "0.0.0.0")
    port = int(os.environ.get("QECTOR_CONNECTOR_PORT", "8000"))
    app = build_app(token=token)
    uvicorn.run(app, host=host, port=port, log_level="info")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())