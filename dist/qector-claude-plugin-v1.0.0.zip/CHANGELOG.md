# Changelog

## 2026-08-16 - All-skills expansion

- Expanded `skills/` to the full set: 7 QECTOR strict-math skills plus all 17
  official Anthropic skills (docx, xlsx, pptx, pdf, doc-coauthoring,
  canvas-design, frontend-design, web-artifacts-builder, webapp-testing,
  algorithmic-art, theme-factory, slack-gif-creator, internal-comms,
  brand-guidelines, claude-api, skill-creator, mcp-builder).
- Added `THIRD_PARTY_NOTICES.md` for the official skills' licenses.
- The hosted plugin ZIP now ships all 24 skills.

## 2026-08-16 - All-in-one consolidation

- Combined the hosted plugin surface (skills, agents, commands, hooks, MCP
  server) with the standalone CLI tooling (`bin/`), the public F2 ground
  truth, and the device-local math obligations in one repository.
- `bin/pro_pack.py` builds the claude.ai-safe plugin ZIP from this repository,
  excluding the tooling paths (`bin/`, `tests/`, ground truth, validation
  docs) so the hosted plugin never ships a top-level `bin/` directory.
- Hook helpers live in `scripts/` and are declared via `hooks/hooks.json`;
  the MCP server is declared via `.mcp.json`.
- The hosted plugin itself is published separately as
  `GuillaumeLessard/qector-claude-plugin`.

## 1.0.0 - 2026-08-15

- Pinned the production library path to the live PyPI wheel `qector-decoder-v3==1.0.0`.
- Pinned the tested MCP runtime to `mcp==1.26.0` and added a low-level stdio adapter.
- Corrected parity-check matrix orientation to `(n_checks, n_qubits)`.
- Added strict binary input validation, graphlike eligibility checks, resource limits,
  fail-closed syndrome verification, and MCP `isError` responses without trace leakage.
- Added hashed raw JSON LER artifacts with Wilson 95% intervals and required metadata.
- Added `qector_math_ground_truth.py` and executable reference-manual proof obligations.
- Made the library server the only default MCP configuration; Workbench is opt-in.
- Aligned public skills, agents, commands, prompts, and documentation with the
  pinned runtime and device-local validation model.
- Removed internal authoring material, machine snapshots, business proposals,
  and proprietary reference documents from the public package.

Performance, GPU, threshold, and universal optimality claims remain workload-scoped;
this plugin does not publish portable speed claims.
