# Security

## Trust Boundaries

- `qector-library` validates binary inputs, dimensions, resource limits, and
  decode faithfulness. It is the only default server.
- `qector-research` is an explicit opt-in surface. Artifact hashing is limited
  to `QECTOR_ARTIFACT_DIR`.
- `qector-admin` is disabled unless `QECTOR_ADMIN_ENABLED=1` is set and every
  mutating call includes `confirm=true`.

## Privileged Operations

`system_setup` accepts fixed profiles only: `production`, `developer`,
`optional-stim`, and `optional-qiskit`. It does not accept arbitrary package
specifications. `workbench_probe` requires an executable within
`QECTOR_WORKBENCH_DIR`, an expected SHA-256 digest, and explicit confirmation.

## Built-in Call Budgets

Agents have no external rate limiter, so the MCP process enforces its own
ceilings. These tools charge a per-process counter and fail closed with
`RESOURCE_LIMIT` when the budget is exhausted:

| Tool | Default max calls / process | Why it is limited |
| --- | ---: | --- |
| `threshold_sweep` | 8 | Writes hashed artifacts and can run a large LER grid |
| `decode_single` | 64 | Seeded decode loop; unbounded agent retries |
| `decode_syndrome` | 256 | Per-call decode compute |
| `build_code_from_matrix` | 32 | Allocates and validates an arbitrary parity-check matrix |
| `hot_path_microbench` | 4 | Machine-scoped measurement, not a portable claim |
| `system_setup` | 2 | Can install packages and write local directories |
| `configure_claude_desktop` | 2 | Rewrites Claude Desktop configuration |
| `workbench_probe` | 2 | Launches a local executable |

Override a single ceiling with `QECTOR_MCP_MAX_CALLS_<TOOL_NAME>` (uppercase).
Set the value to `-1` to disable that tool's budget. Input-size ceilings
(`QECTOR_MCP_MAX_DISTANCE`, `QECTOR_MCP_MAX_TRIALS`,
`QECTOR_MCP_MAX_SWEEP_POINTS`, `QECTOR_MCP_MAX_MATRIX_CELLS`) still apply on
every call.

## Network Boundary

Default operation is local-only. The only network-capable tool arguments are
the explicit PyPI freshness checks documented in `PRIVACY.md`. Do not enable
them in air-gapped deployments.

## Reporting

Report vulnerabilities privately to <admin@qector.store>. Do not include
licenses, credentials, private matrices, or customer artifacts in reports.
